import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../models/catalog.dart';
import '../../providers/core_providers.dart';
import '../../widgets/common.dart';
import '../player/player_providers.dart';

final lyricsProvider = FutureProvider.family<Lyrics, String>((ref, songId) => ref.read(musicRepositoryProvider).lyrics(songId));

class LyricsScreen extends ConsumerWidget {
  const LyricsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final track = ref.watch(currentTrackProvider);
    return Scaffold(
      backgroundColor: const Color(0xFF2A2140),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: track == null
            ? const Text('Lyrics')
            : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(track.title, style: const TextStyle(fontSize: 16)),
                Text(track.artistNames, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ]),
      ),
      body: track == null
          ? const EmptyView(icon: Icons.lyrics_outlined, message: 'Nothing is playing')
          : ref.watch(lyricsProvider(track.id)).when(
                loading: () => loadingView,
                error: (e, _) => ErrorView(error: e, onRetry: () => ref.invalidate(lyricsProvider(track.id))),
                data: (lyrics) {
                  if (lyrics.instrumental) {
                    return const EmptyView(icon: Icons.piano, message: 'This track is instrumental');
                  }
                  if (!lyrics.available) {
                    return const EmptyView(icon: Icons.lyrics_outlined, message: 'Lyrics aren\'t available for this song');
                  }
                  if (!lyrics.synced) return _PlainLyrics(text: lyrics.plainText ?? '');
                  return _SyncedLyrics(lyrics: lyrics);
                },
              ),
    );
  }
}

class _PlainLyrics extends StatelessWidget {
  const _PlainLyrics({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('These lyrics aren\'t time-synced.', style: TextStyle(color: AppColors.textSecondary)),
          const SizedBox(height: 16),
          Text(text, style: const TextStyle(fontSize: 20, height: 1.6, fontWeight: FontWeight.w600)),
        ],
      );
}

class _SyncedLyrics extends ConsumerStatefulWidget {
  const _SyncedLyrics({required this.lyrics});
  final Lyrics lyrics;

  @override
  ConsumerState<_SyncedLyrics> createState() => _SyncedLyricsState();
}

class _SyncedLyricsState extends ConsumerState<_SyncedLyrics> {
  final _scroll = ScrollController();
  final _keys = <int, GlobalKey>{};
  int _current = -1;
  DateTime _userScrolledAt = DateTime.fromMillisecondsSinceEpoch(0);

  bool get _autoScroll => DateTime.now().difference(_userScrolledAt) > const Duration(seconds: 4);

  void _scrollTo(int index) {
    final ctx = _keys[index]?.currentContext;
    if (ctx == null || !_autoScroll) return;
    Scrollable.ensureVisible(ctx, alignment: 0.35, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final position = ref.watch(positionProvider).value ?? Duration.zero;
    final index = widget.lyrics.lineIndexAt(position);
    if (index != _current) {
      _current = index;
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollTo(index));
    }
    return NotificationListener<UserScrollNotification>(
      onNotification: (n) {
        if (n.direction != ScrollDirection.idle) _userScrolledAt = DateTime.now();
        return false;
      },
      child: ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 240),
        itemCount: widget.lyrics.lines.length,
        itemBuilder: (context, i) {
          final line = widget.lyrics.lines[i];
          final active = i == index;
          return GestureDetector(
            key: _keys.putIfAbsent(i, GlobalKey.new),
            // Tap a line to jump there.
            onTap: () {
              _userScrolledAt = DateTime.fromMillisecondsSinceEpoch(0);
              ref.read(audioHandlerProvider).seek(line.time);
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(
                  fontSize: 24,
                  height: 1.3,
                  fontWeight: FontWeight.bold,
                  color: active ? Colors.white : (i < index ? Colors.white60 : Colors.white30),
                ),
                child: Text(line.text.isEmpty ? '♪' : line.text),
              ),
            ),
          );
        },
      ),
    );
  }
}
