import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/core_providers.dart';
import '../../widgets/common.dart';
import '../../widgets/track_tile.dart';
import '../session/session_controller.dart';
import '../library/library_providers.dart';
import 'player_providers.dart';
import 'widgets/seek_bar.dart';

class PlayerScreen extends ConsumerWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final track = ref.watch(currentTrackProvider);
    final handler = ref.read(audioHandlerProvider);
    if (track == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyView(icon: Icons.music_off, message: 'Nothing is playing'));
    }
    final state = ref.watch(playbackStateProvider).value;
    final playing = state?.playing ?? false;
    final loading = state?.processingState == AudioProcessingState.loading;
    final shuffle = state?.shuffleMode == AudioServiceShuffleMode.all;
    final repeat = state?.repeatMode ?? AudioServiceRepeatMode.none;
    final liked = ref.watch(isLikedProvider(track.id));
    final context_ = handler.playContext;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.keyboard_arrow_down), onPressed: () => context.pop()),
        centerTitle: true,
        title: Column(children: [
          const Text('PLAYING FROM', style: TextStyle(fontSize: 10, letterSpacing: 1, color: AppColors.textSecondary)),
          Text(_contextLabel(context_), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () => showTrackMenu(context, ref, track)),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(builder: (context, c) {
          final art = (c.maxWidth - 48).clamp(120.0, c.maxHeight * 0.48);
          return Column(children: [
            const Spacer(),
            Hero(tag: 'artwork', child: ArtworkImage(url: track.artwork.best, size: art, radius: 8)),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    GestureDetector(
                      onTap: () {
                        final a = track.artists.where((a) => a.id != null).firstOrNull;
                        if (a != null) context.push('/artist/${a.id}');
                      },
                      child: Text(track.artistNames, maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 15, color: AppColors.textSecondary)),
                    ),
                  ]),
                ),
                IconButton(
                  tooltip: liked ? 'Remove from Liked Songs' : 'Like',
                  icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                      color: liked ? AppColors.accent : Colors.white, size: 28),
                  onPressed: () async {
                    try {
                      await ref.read(likedSongsProvider.notifier).toggle(track);
                    } catch (e) {
                      if (context.mounted) showError(context, e);
                    }
                  },
                ),
              ]),
            ),
            const SizedBox(height: 8),
            const SeekBar(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                IconButton(
                  tooltip: 'Shuffle',
                  icon: Icon(Icons.shuffle, color: shuffle ? AppColors.accent : Colors.white),
                  onPressed: () => handler.setShuffleMode(shuffle ? AudioServiceShuffleMode.none : AudioServiceShuffleMode.all),
                ),
                IconButton(
                  tooltip: 'Previous',
                  iconSize: 40,
                  icon: const Icon(Icons.skip_previous),
                  onPressed: handler.skipToPrevious,
                ),
                SizedBox(
                  width: 68,
                  height: 68,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: const CircleBorder(),
                      padding: EdgeInsets.zero,
                      minimumSize: const Size(68, 68),
                    ),
                    onPressed: loading ? null : (playing ? handler.pause : handler.play),
                    child: loading
                        ? const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.black))
                        : Icon(playing ? Icons.pause : Icons.play_arrow, size: 38, color: Colors.black),
                  ),
                ),
                IconButton(tooltip: 'Next', iconSize: 40, icon: const Icon(Icons.skip_next), onPressed: handler.skipToNext),
                IconButton(
                  tooltip: 'Repeat',
                  icon: Icon(
                    repeat == AudioServiceRepeatMode.one ? Icons.repeat_one : Icons.repeat,
                    color: repeat == AudioServiceRepeatMode.none ? Colors.white : AppColors.accent,
                  ),
                  onPressed: () => handler.setRepeatMode(switch (repeat) {
                    AudioServiceRepeatMode.none => AudioServiceRepeatMode.all,
                    AudioServiceRepeatMode.all || AudioServiceRepeatMode.group => AudioServiceRepeatMode.one,
                    AudioServiceRepeatMode.one => AudioServiceRepeatMode.none,
                  }),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                TextButton.icon(
                  onPressed: () => _showQualitySheet(context, ref),
                  icon: const Icon(Icons.graphic_eq, size: 18),
                  label: Text(_qualityLabel(handler.activeStreamQuality ?? handler.quality)),
                ),
                Row(children: [
                  IconButton(tooltip: 'Lyrics', icon: const Icon(Icons.lyrics_outlined), onPressed: () => context.push('/lyrics')),
                  IconButton(tooltip: 'Queue', icon: const Icon(Icons.queue_music), onPressed: () => context.push('/queue')),
                ]),
              ]),
            ),
          ]);
        }),
      ),
    );
  }

  static String _contextLabel(String? c) {
    if (c == null) return 'Your music';
    final i = c.indexOf(':');
    return i < 0 ? c : c.substring(i + 1);
  }

  static String _qualityLabel(String q) => AppConfig.audioQualities[q]?.split(' ').first ?? q;

  void _showQualitySheet(BuildContext context, WidgetRef ref) {
    final handler = ref.read(audioHandlerProvider);
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Audio quality', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          if (handler.activeStreamQuality != null && handler.activeStreamQuality != handler.quality)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'This song isn\'t available in ${AppConfig.audioQualities[handler.quality]}; '
                'playing ${AppConfig.audioQualities[handler.activeStreamQuality]}.',
                style: const TextStyle(color: AppColors.textSecondary),
              ),
            ),
          RadioGroup<String>(
            groupValue: handler.quality,
            onChanged: (q) async {
              if (q == null) return;
              Navigator.pop(ctx);
              try {
                await ref.read(sessionProvider.notifier).updatePreferences(audioQuality: q);
              } catch (e) {
                await handler.setQuality(q); // still apply locally if saving the preference failed
                if (context.mounted) showError(context, e);
              }
            },
            child: Column(children: [
              for (final e in AppConfig.audioQualities.entries) RadioListTile<String>(value: e.key, title: Text(e.value)),
            ]),
          ),
        ]),
      ),
    );
  }
}
