import 'package:audio_service/audio_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/track.dart';
import '../../providers/core_providers.dart';

final playbackStateProvider = StreamProvider<PlaybackState>((ref) {
  final h = ref.watch(audioHandlerProvider);
  return h.playbackState;
});

final currentMediaItemProvider = StreamProvider<MediaItem?>((ref) => ref.watch(audioHandlerProvider).mediaItem);

/// The playing track (decoded from the MediaItem extras).
final currentTrackProvider = Provider<Track?>((ref) {
  final item = ref.watch(currentMediaItemProvider).value;
  final json = item?.extras?['track'];
  return json is Map ? Track.fromJson(Map<String, dynamic>.from(json)) : null;
});

final queueProvider = StreamProvider<List<MediaItem>>((ref) => ref.watch(audioHandlerProvider).queue);

/// Single position source for every player UI (full player, mini player, lyrics).
/// Uses the handler's display position so a restored-but-not-yet-loaded song shows
/// where it will resume.
final positionProvider = StreamProvider<Duration>((ref) {
  final h = ref.watch(audioHandlerProvider);
  return Stream.periodic(const Duration(milliseconds: 200), (_) => h.displayPosition).distinct();
});

final bufferedPositionProvider =
    StreamProvider<Duration>((ref) => ref.watch(audioHandlerProvider).bufferedPositionStream);
